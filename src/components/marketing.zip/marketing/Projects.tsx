export default function Projects() {
    return (
        <div>
            <h1>This is Marketing Page</h1>
        </div>
    );
}
